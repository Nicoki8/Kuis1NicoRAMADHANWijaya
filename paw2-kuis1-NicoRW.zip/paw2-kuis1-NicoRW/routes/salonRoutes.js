const express = require('express');
const router = express.Router();
const salonController = require('../controllers/salonController');
const cekApiKey = require('../middlewares/cekApiKey');

router.get('/', salonController.getAllServices);
router.get('/:id', salonController.getServiceById);

// Dilindungi API Key
router.post('/', cekApiKey, salonController.createService);
router.put('/:id', cekApiKey, salonController.updateService);
router.delete('/:id', cekApiKey, salonController.deleteService);

module.exports = router;
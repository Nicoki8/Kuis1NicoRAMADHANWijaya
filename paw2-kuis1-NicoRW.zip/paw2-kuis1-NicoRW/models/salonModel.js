let salonServices = [
    { id: 1, namaLayanan: "Potong Rambut Stylist (Nico)", kategori: "rambut", durasiMenit: 45, harga: 75000, tersedia: true },
    { id: 2, namaLayanan: "Facial Treatment", kategori: "wajah", durasiMenit: 60, harga: 150000, tersedia: true },
    { id: 3, namaLayanan: "Manicure & Pedicure", kategori: "kuku", durasiMenit: 90, harga: 120000, tersedia: false }
];

let nextId = 4;

module.exports = {
    getAll: () => salonServices,
    getById: (id) => salonServices.find(s => s.id === parseInt(id)),
    create: (data) => {
        const newService = { id: nextId++, ...data };
        salonServices.push(newService);
        return newService;
    },
    update: (id, data) => {
        const index = salonServices.findIndex(s => s.id === parseInt(id));
        if (index === -1) return null;
        salonServices[index] = { id: parseInt(id), ...data };
        return salonServices[index];
    },
    remove: (id) => {
        const index = salonServices.findIndex(s => s.id === parseInt(id));
        if (index === -1) return null;
        const deleted = salonServices.splice(index, 1);
        return deleted[0];
    }
};
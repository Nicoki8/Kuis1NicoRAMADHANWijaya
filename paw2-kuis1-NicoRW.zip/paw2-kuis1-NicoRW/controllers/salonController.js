const salonModel = require('../models/salonModel');

const salonController = {
    getAllServices: (req, res) => {
        const { kategori, tersedia } = req.query;
        let results = salonModel.getAll();

        if (kategori) {
            results = results.filter(s => s.kategori.toLowerCase() === kategori.toLowerCase());
        }
        if (tersedia !== undefined) {
            const isAvailable = tersedia === 'true';
            results = results.filter(s => s.tersedia === isAvailable);
        }

        res.status(200).json({
            success: true,
            message: "Berhasil mengambil data layanan salon",
            total: results.length,
            data: results
        });
    },

    getServiceById: (req, res) => {
        const service = salonModel.getById(req.params.id);
        if (!service) {
            return res.status(404).json({ success: false, message: "Layanan salon tidak ditemukan" });
        }
        res.status(200).json({ success: true, data: service });
    },

    createService: (req, res) => {
        const { namaLayanan, kategori, durasiMenit, harga, tersedia } = req.body;
        
        if (!namaLayanan || !kategori || durasiMenit === undefined || harga === undefined || tersedia === undefined) {
            return res.status(400).json({ success: false, message: "Semua field wajib diisi (namaLayanan, kategori, durasiMenit, harga, tersedia)" });
        }

        const validKategori = ["rambut", "wajah", "kuku"];
        if (!validKategori.includes(kategori.toLowerCase())) {
            return res.status(400).json({ success: false, message: "Kategori harus bernilai: rambut, wajah, atau kuku" });
        }

        const newService = salonModel.create({ namaLayanan, kategori: kategori.toLowerCase(), durasiMenit, harga, tersedia });
        res.status(201).json({ success: true, message: "Layanan salon berhasil ditambahkan", data: newService });
    },

    updateService: (req, res) => {
        const { namaLayanan, kategori, durasiMenit, harga, tersedia } = req.body;

        if (!namaLayanan || !kategori || durasiMenit === undefined || harga === undefined || tersedia === undefined) {
            return res.status(400).json({ success: false, message: "Semua field wajib diisi untuk pembaruan" });
        }

        const updated = salonModel.update(req.params.id, { namaLayanan, kategori, durasiMenit, harga, tersedia });
        if (!updated) {
            return res.status(404).json({ success: false, message: "Layanan salon yang akan diubah tidak ditemukan" });
        }

        res.status(200).json({ success: true, message: "Layanan salon berhasil diperbarui", data: updated });
    },

    deleteService: (req, res) => {
        const deleted = salonModel.remove(req.params.id);
        if (!deleted) {
            return res.status(404).json({ success: false, message: "Layanan salon yang akan dihapus tidak ditemukan" });
        }
        res.status(200).json({ success: true, message: "Layanan salon berhasil dihapus", data: deleted });
    }
};

module.exports = salonController;
const notFoundHandler = (req, res, next) => {
    res.status(404).json({ success: false, message: "Endpoint atau rute tidak ditemukan" });
};

const globalErrorHandler = (err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ success: false, message: "Terjadi kesalahan pada server", error: err.message });
};

module.exports = { notFoundHandler, globalErrorHandler };
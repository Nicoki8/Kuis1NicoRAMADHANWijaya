require('dotenv').config();
const express = require('express');
const cors = require('cors');
const logger = require('./middlewares/logger');
const { notFoundHandler, globalErrorHandler } = require('./middlewares/errorHandler');
const salonRoutes = require('./routes/salonRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(logger);

app.get('/', (req, res) => {
    res.status(200).json({
        success: true,
        message: "Selamat datang di API Kuis 1 Salon",
        author: "Nico Ramadhan Wijaya (2327240083)"
    });
});

app.use('/salon-services', salonRoutes);

app.use(notFoundHandler);
app.use(globalErrorHandler);

app.listen(PORT, () => {
    console.log(`Server Kuis 1 berjalan di http://localhost:${PORT}`);
});